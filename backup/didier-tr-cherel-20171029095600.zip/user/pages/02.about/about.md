---
Title: About-Me

template: default

---

# About me

Hello everyone!

My name is Didier Trécherel, I'm a french engineer in Computer Science & I specialize in Computer Security. I made this website to post some writeups on wargames CTF or other things. The purpose is simply to share what I learnt. :-)

You can follow me on twitter, [@dtrecherel][1]

PS: if you have any question, or would like to contact me, here's my email address: <didier.trecherel@gmail.com>

So yeah, this is just my small corner of the web :-)

[1]: http://twitter.com/dtrecherel "Didier Trécherel on Twitter"