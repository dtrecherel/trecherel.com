---
title: WIP - ANSSI - Behind the wallpaper
slug: anssi/wallpaper
template: item
date: 28-10-2015

taxonomy:
	categorie: [ANSSI]
	tag: [WIP, ANSSI, OCR]
---

In 2012, the [National Cybersecurity Agency of France][ANS] (*Agence nationale de la sécurité des systèmes d'information*, ANSSI) published a new wallpaper with a small particularity: a challenge was hidden inside. **This post is still a WIP.**

===

Here is the wallpaper:

![ANSSI wallpaper][WAL]  

Now, let's start!

## Logo analysis

I already had the opportunity to go inside their office, and I remember seeing this big logo near the front door. I was wondering what the small inscriptions meant. (The ones we can see in the inner ring.)

![The logo][LOG]  

Here are the inscriptions we can see:

```text
Top:
A125894294F6A08D 
FDC21B055809130B 
D873AD692D563156 
F0450B4A33EB5315 
E99C64710CD78CDB 
AD2EEEF2E168A0EA 
8F2320C340CF7BBF 
52CC2D94BFA89E01 
613094E58C727F72 
3ACE254275121653 
EE46D39D1103A044 
8298EDE384A73E7E

Bottom:
TGUgc291cmlyZSBkZSBsYSBKb2NvbmRlIGNhY2hhaXQgYmllbiBkZXMgbXlzdOhyZXMuLi4K
AUTH : DE9C9C55 : PCA
```

La première partie semble représenter 12 blocs de 8 octets. La nature des chiffres hexadécimaux écarte l'idée d'une chaîne de caractères. En effet, la plupart des octets ne représentent pas des caractères affichables. Peut-être que ces données ont été chiffrées, ou peut-être qu'ils seront utiles à un autre problème plus tard. Je décide de les laisser de côté pour l'instant.

La seconde donne un peu plus d'information. La longue chaîne `TGUgc291cmlyZSBkZSBsYSBKb2NvbmRlIGNhY2hhaXQgYmllbiBkZXMgbXlzdOhyZXMuLi4K` paraît avoir été encodée en base64. Une fois décodée, on obtient:
`Le sourire de la Joconde cachait bien des mystères...`

## Stéganographie LSB

Ma seconde approche a été d'analyser l'image pour retrouver d'éventuelles informations cachées par la méthode LSB (*Least Significant Bit*). J'ai utilisé `Steganabara` pour mettre en évidence des informations cachées dans les 3 couches rouge, verte et bleue.

![Des informations sont cachées dans les bits de poids faibles][3I]  
*Des informations sont cachées dans les bits de poids faibles*

Aussi, deux phrases apparaissent:

```
LA PERSEVERANCE EST LA NOBLESSE DE L'OBSTINATION
LES MOMENTS LES PLUS DIFFICILES SONT CEUX QUI DONNENT LE PLUS DE SATISFACTION
```

L'ANSSI chercherait-elle à nous encourager?

J'ai créé un script en python pour procéder à la reconnaissance des caractères. Celui-ci est disponible dans le dossier `OCR` (pour Optical character recognition).

### Couche rouge

Les données lues sur la couche rouge correspondent à une archive `bzip2`:

```
$ file data_red.bin 
data_red.bin: bzip2 compressed data, block size = 900k
``` 

[ANS]: https://www.ssi.gouv.fr "ANSSI webpage"
[WAL]: files/Logo/Logo.png "ANSSI Walpaper"
[LOG]: files/Parts/Medaille.png "Logo"
[3I]: files/LSB/RGB_LSB.png "Informations cachées"
