# v0.2.1
##  07/27/2016

1. [](#bugfix)
    * Fix running plugin without adding CSS files to include [#2](https://github.com/getgrav/grav-plugin-custom-css/issues/2)

# v0.2.0
##  05/23/2016

1. [](#new)
    * Added field to manipulate priority

# v0.1.0
##  05/02/2016

1. [](#new)
    * ChangeLog started...
