---
title: Home
visible: true
template: home
---

# Hello, world!
Haywire is a modern starter theme for [Grav](https://github.com/getgrav/grav). The idea behind the theme is to help developers get started quickly on their new grav projects using modern frameworks and tools such as [laravel-mix](https://github.com/JeffreyWay/laravel-mix), [vuejs](https://github.com/vuejs/vue), and [bulma](https://github.com/jgthms/bulma).
